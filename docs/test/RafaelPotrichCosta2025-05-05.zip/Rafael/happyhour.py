totalpessoas = int(input("Digite o total de pessoas: "))
valorconta = float(input("Digite o valor da conta: "))
valordivido = valorconta / totalpessoas
for i in range(1, (totalpessoas + 1)):
    print (f"Valor a pagar por pessoa: {i}", valordivido)