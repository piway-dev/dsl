selcadeira = int()
status = 0
for i in range (1, 71):
    print (i, status)

cadeira = 0

if status == 0:
    print("Disponĩvel")
else:
    print ("Indisponível")

if cadeira == 0:
    status = 0
if cadeira == 1:
    status = 1

while True:
    print ("\n1- Listar cadeiras", "\n2- Reservar cadeira", "\n3- Sair")
    selecao = int(input("Digite a opção que você deseja: "))
    
    if selecao == 3:
        break

