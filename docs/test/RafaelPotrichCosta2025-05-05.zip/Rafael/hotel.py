hospedes = int(input("Digite o total de hóspedes: "))
hospedesadultos = 0
hospedesadolescentes = 0
hospedescriancas = 0
for i in range (1, (hospedes + 1)):
    idade = int(input("Digite a idade do hóspede: "))
    if idade >= 18:
        hospedesadultos += 1
    elif idade >= 12 and idade <= 17:
        hospedesadolescentes += 1
    elif idade < 12:
        hospedescriancas += 1
print ("Relatório de hóspedes:", "\nNúmero total de hóspedes:", hospedes, "\nNúmero total de adultos (pessoas maiores de 18 anos):", hospedesadultos, "\nNúmero total de adolescentes (pessoas com idade entre 12 e 17 anos):", hospedesadolescentes, "\nNúmero total de crianças (pessoas com menos de 12 anos):", hospedescriancas)