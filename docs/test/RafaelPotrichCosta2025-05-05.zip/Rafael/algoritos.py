lanches = ['(S) Sanduíche', '(C) Cachorro quente', '(P) Pastel']
sanduiches = ["1 - Vegetariano", "2 - Frango", "3 - Calabresa"]
cachorro = ['1 - Salsicha tradicional', '2 - Salsicha calabresa', '3 - Salsicha de frango']
pastel = ['1 - Carne', '2 - Frango', '3 - Presunto e queijo']
acompanhamentos = ['1 - Catupiry', '2 - Cream cheese', '3 - Barbecue']
bebidas = ['1 - Água', '2 - Suco', '3 - Refrigerante', '4 - Café']
pedidos = []
valor = []
while True:
    print ("Menu: ", "\n", lanches)
    selecao = input("Digite o tipo de lanche que deseja.")
    
    if selecao == 'S' or 's':
        valor.append(5)
        pedidos.append("S")
        print ("Tipos de sanduíche:", sanduiches)
        selecaosanduiches = int(input("Selecione o tipo do seu sanduíche: "))
        pedidos.append(selecaosanduiches)

    elif selecao == 'C' or 'c':
        valor.append(6)
        pedidos.append("C")
        print ("Tipos de Cachorro-Quente:", cachorro)
        selecaocachorro = int(input("Selecione o tipo do seu sanduíche: "))
        pedidos.append(selecaocachorro)
    
    elif selecao == 'P' or 'p':
        valor.append(4)
        pedidos.append("P")
        print ("Tipos de Pastel:", pastel)
        selecaopastel = int(input("Selecione o tipo do seu pastel: "))
        pedidos.append(selecaopastel)

    selacompanhamento = input("Deseja acompanhamento? (S/N): ")
    pedidos.append('C')

    if selacompanhamento == 'N' or 'n':
        pedidos.append(0)    

    if selacompanhamento == 'S' or 's':
        print ("Opções de acompanhamento:", acompanhamentos)
        selacompanhamento2 = int(input("Selecione a opção de acompanhamento que deseja: "))
        pedidos.append(selacompanhamento2)
        if selacompanhamento2 == 1:
            valor.append(1)
        elif selacompanhamento2 ==2:
            valor.append(1.20)
        elif selacompanhamento2 ==3:
            valor.append(0.80)
    
    selbebida = input("Deseja bebida? (S/N): ")
    pedidos.append('B')
    if selbebida == 'N' or 'n':
        pedidos.append(0)
    
    if selbebida == 'S' or 's':
        print ('Opções de bebidas:', bebidas)
        selbebida2 = int(input("Selecione a bebida que deseja: "))
        pedidos.append(selbebida2)
        if selbebida2 == 1:
            valor.append(2)
        elif selbebida2 == 2:
            valor.append(3)
        elif selbebida2 == 3:
            valor.append(3)
        elif selbebida2 == 4:
            valor.append(2)
    print ("O ticket do seu pedido é:", pedidos)
    valorlanche = float(sum(valor))
    print ('O valor do seu pedido ẽ:', valorlanche)
    valorpago = float(input("Valor a pagar: "))
    valortroco = valorpago - valorlanche
    print ("Seu troco é de: ", valortroco)
    break
    

