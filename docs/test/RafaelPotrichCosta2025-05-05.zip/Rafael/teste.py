totalpessoas = int(input("Digite o total de pessoas: "))
valorconta = float(input("Digite o valor da conta: "))

valordivido = valorconta / totalpessoas
print (valordivido)