#include  <stdio.h>
#include  <string.h>
int main() {
   
  int tipo , stipo ,complemento, scomplemento 
  return 0;
}