#include <stdio.h>

int main() {
   
  float valort, pessoas ,valorap; // declarando variaveis

  printf("Valor Total da  conta: \n"); //  entrada valor total
 scanf("%f", &valort);

  printf("Quantidade de Pessoas:  \n"); // entrada quantidade de pessoas
  scanf("%f", &pessoas);

  valorap = valort/pessoas ; // solução valor a pagar p pessoa


 printf("Valor a pagar Pessoa 1: R$%.2f\n", valorap);
printf("Valor a pagar Pessoa 2: R$%.2f\n", valorap);
 printf("Valor a pagar Pessoa 3: R$%.2f\n", valorap);

  return 0;
}