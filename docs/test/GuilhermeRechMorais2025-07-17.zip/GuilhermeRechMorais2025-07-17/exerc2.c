#include <stdio.h>

int main() {
   
int numhospedes, idade , numadultos, ndecriancas, numdeadolescentes;

 printf("Quantos hóspedes estão hospedados no hotel?: \n");
 scanf("%d", &numhospedes);

for (int i = 1; i < numhospedes; i++) // Condição  que pergunta o N° de Hospedes
{
    printf("Qual a idade do hóspede de n°%d?\n", i); 
    scanf("%d", &idade);
}

 if(idade > 18){
        scanf("%d", &numadultos); //  Armazena o N° de Adultos
    }else if (idade<12){
        scanf("%d", &ndecriancas); //  Armazena o N° de Crianças
    }else{
        scanf("%d", &numdeadolescentes); // Armazena o N°ḍe Adolescentes
    }

printf("O  número total de hóspedes é  de: %d \n", numhospedes);
printf("Possuem %d hóspedes que são adultos\n", numadultos); // Imprime o N° de Adultos
printf("Possuem %d hóspedes que são adolescentes\n", numdeadolescentes); //Imoprime o N° de Adolescentes
printf("Possuem %d hóspedes que são crianças\n", ndecriancas); // Imprime o N° de Crianças

  return 0;
}
