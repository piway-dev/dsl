#include <stdio.h>

int main () {
    int hospedes = 8, adultos = 3, adolescentes = 2, criancas = 3, idade;
    char pessoa[8];

    

    return 0;
}