#include <stdio.h>

int main () {
    float totalConta, calculo, restante;
    int pessoas, i;

    printf("Insira o número de pessoas:");
    scanf("%d", &pessoas);

    printf("\nInsira o total da conta:");
    scanf("%f", &totalConta);

    calculo = totalConta / pessoas;
    restante = totalConta - (calculo * (pessoas - 1));

    if (calculo * pessoas == totalConta) {
        for(i = 1; i <= pessoas - 1; i++) {
        printf("\nValor a pagar pessoa %d: R$ %.2f", i, calculo);
        }
        if(calculo * pessoas + 0.01 != totalConta) {
            printf("\nValor a pagar pessoa %d: R$ %.2f", i, calculo + 0.01);
        } else {
            printf("\nValor a pagar pessoa %d: R$ %.2f", i, calculo);
            printf("\n%.2f", calculo * pessoas);
            printf("\n%.2f", calculo * pessoas + 0.01);
        }
        return 0;
    } else {
        printf("\nErro ao calcular o total.");
    }
    return 0;
}