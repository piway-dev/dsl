
import java.util.Scanner;

public class Questao2 {
   public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);

       System.out.print("Digite a quantidade de hóspedes = ");
       int quantidade = sc.nextInt();

       int [] idadesHospedes = new int[quantidade];
       int adultos = 0;
       int adolescentes = 0;
       int criancas = 0;

       for(int i = 0 ; i < quantidade ; i++){
            System.out.print("Digite a idade do " + (i + 1) + " hóspedes = ");
            idadesHospedes[i] = sc.nextInt();
       }

       for(int i = 0 ; i < idadesHospedes.length ; i++){
            if(idadesHospedes[i] > 18){
                adultos++;
            }
            else if(idadesHospedes[i] < 12){
                criancas++;
            }
            else if(idadesHospedes[i] >= 12 && idadesHospedes[i] <= 18){
                adolescentes++;
            }
       }


       System.out.println("======= Relatório =======");
       System.out.println("Número de Hóspedes = " + quantidade);
       System.out.println("Número de Adultos = " + adultos);
       System.out.println("Número de Adolescentes =  " + adolescentes);
       System.out.println("Número de Crianças =  " + criancas);

   }
}


