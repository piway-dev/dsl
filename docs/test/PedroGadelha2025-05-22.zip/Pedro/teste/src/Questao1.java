import java.util.Scanner;

public class Questao1 {
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);

        System.out.print("Total da conta: ");
        double valorTotal = sc.nextDouble();

        System.out.print("\n Quantidade de pessoas: ");
        int quantidade = sc.nextInt();

        double valorPorPessoa = valorTotal / quantidade;

        for(int i = 0; i < quantidade ; i++){
            System.out.printf("\n Valor a pagar por pessoa "+ (i + 1)  + " = %.2f " , valorPorPessoa );
        }

        


        

    }
}
