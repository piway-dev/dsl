public class Poltrona {
    private int fileira;
    private int numero;
    private boolean livre;
    private double preco;

    public Poltrona() {
    }

    public Poltrona(int fileira, boolean livre, int numero, double preco) {
        this.fileira = fileira;
        this.livre = livre;
        this.numero = numero;
        this.preco = preco;
    }

    public int getFileira() {
        return fileira;
    }

    public int getNumero() {
        return numero;
    }

    public boolean isLivre() {
        return livre;
    }

    public double getPreco() {
        return preco;
    }

    @Override
    public String toString() {
        return "\nPoltrona [fileira=" + fileira + ", numero=" + numero + ", livre=" + livre + ", preco=" + preco + "]";
    }


    
}
