
import java.util.Scanner;

public class Questao4 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        
        System.out.print("Digite a opçao de Lanche: (S, C, P): ");
        char lanche = sc.next().charAt(0);

        int sabor = 0;
        int acompanhamento = 0;
        int bebida = 0;

        double valorLanche = 0;
        double valorAcompanhamento = 0;
        double valorBebida = 0;
        
       
       

        if(lanche == 'S'){
            System.out.print("\n Escolha o sabor do sanduíche (1 - Vegetariano, 2 - Frango, 3 - Calabresa): ");
            sabor = sc.nextInt();
        }

        if(lanche == 'C'){
            System.out.print("\n Escolha o sabor do cachorro-quente (1 - Salsicha tradicional, 2 - Salsicha calabresa, 3 - Salsicha de frango): ");
            sabor = sc.nextInt();
        }

        if(lanche == 'P'){
            System.out.print("\n Escolha o sabor do Pastel (1 - Carne, 2 - Frango, 3 - Presunto e queijo): ");
            sabor = sc.nextInt();
        }

        System.out.print("\nVocê deseja acompanhamento para o seu lanche? (S/N):  ");
        char temAcompanhamento = sc.next().charAt(0);

        if(temAcompanhamento == 'S'){
            System.out.print("\n Escolha o seu acompanhamento : (1 - Catupiry, 2 - Cream cheese, 3 - Barbecue): ");
            acompanhamento = sc.nextInt();
        }

        System.out.print("\nVocê deseja alguma bebida? (S/N):  ");
        char temsBebida = sc.next().charAt(0);

        if(temsBebida == 'S'){
            System.out.print("\n Escolha a sua bebida:  (1 - Água, 2 - Suco, 3 - Refrigerante, 4 - Café): ");
            bebida = sc.nextInt();
        }

        switch (lanche) {
            case 'S' -> valorLanche = 5.00;
            case 'C' -> valorLanche = 6.00;
            case 'P' -> valorLanche = 4.00;
            default -> {
            }
        }

        switch (acompanhamento) {
            case 1 -> valorAcompanhamento = 1.00;
            case 2 -> valorAcompanhamento = 1.20;
            case 3 -> valorAcompanhamento = 0.80;
            default -> {
            }
        }

        switch (bebida) {
            case 1 -> valorBebida = 2.00;
            case 2 -> valorAcompanhamento = 3.00;
            case 3 -> valorAcompanhamento = 3.00;
            case 4 -> valorAcompanhamento = 2.00;
            default -> {
            }
        }

         double valorConta = valorLanche + valorAcompanhamento + valorBebida;

        


        System.out.printf("LANCHE " + lanche + sabor + "C" +acompanhamento + "B" +bebida + " R$ %.2f" + valorConta);

        System.out.print("\n Pagamento = ");
        double pagamento = sc.nextDouble();
        double troco = valorConta - pagamento;


        if(pagamento < valorConta){
            System.out.println("Saldo insuficiente!");
        }
        else{
            System.out.println("Troco = " + troco);
        }

        



    }
}
