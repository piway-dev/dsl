
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;




public class Questao3 {
    public static void main(String[] args) {

        //NT

        Scanner sc = new Scanner(System.in);

        List<Poltrona> poltronas = new ArrayList<>();
        Poltrona poltrona = new Poltrona();

        for(int i = 1 ; i <= 70 ; i++){
            if(i > 1 && i <= 10){
                poltrona = new Poltrona(1, true, i, 100);
            }
            else if(i > 10 && i <= 20){
                poltrona = new Poltrona(2, true, i, 90);
            }
            else if(i > 20 && i <= 30){
                poltrona = new Poltrona(3, true, i, 80);
            }
            else if(i > 30 && i <= 40){
                poltrona = new Poltrona(4, true, i, 70);
            }
            else if(i > 40 && i <= 50){
                poltrona = new Poltrona(5, true, i, 60);
            }
            else if(i > 50 && i <= 60){
                poltrona = new Poltrona(6, true, i, 50);
            }
            else if(i > 60 && i <= 70){
                poltrona = new Poltrona(7, true, i, 40);
            }
            poltronas.add(poltrona);

        }

        while(true){
            System.out.println("========== Teatro ==========");

            System.out.print("Escolha uma opção: ");
            int opcao = sc.nextInt();

            System.out.println("1.Cadeiras");
            System.out.println("2.Reservar ");
            System.out.println("3.Sair");

            switch (opcao) {
                case 1:
                    System.out.println(poltronas);
                    break;

                case 2:
                    System.out.print("Escolha o número da poltrona:");
                    int numero = sc.nextInt();

                    for(Poltrona p : poltronas){
                        //NS
                    }

                default:
                    throw new AssertionError();
            }

        }

    }   
}
