//4 função
#include <stdio.h>

gint main(){

}