//3 matriz
#include <stdio.h>

int main(){
    int i, j;
    for (i = 0; i < 7; i++){
        for (j = 0; j < 10; j++){

        }
    }   
}