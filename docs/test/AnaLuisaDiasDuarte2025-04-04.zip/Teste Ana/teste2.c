//2 for
#include <stdio.h>

int main(){
    int idade, total, adulto, crianca, adolescente, i;

    printf("Digite a idade do hospede: ",idade);
    scanf("%d", &idade);

    if (idade>=18){
        printf("Hospede adulto cadastrado!\n", adulto);
    }
    if (idade>=12){
        printf("Hospede adolescente cadastrado!\n", adolescente);
    }
    else{
        printf("Hospede criança cadastrado!\n", crianca);
    }
}

//Lógica que que pensei mas não consegui executar: faria um laço de repetição que solicitaria a idade do hospede 
//e pararia quando solicitado, as idades cadastradas ficariam separadas pelas condições e no final calculado printaria
//na tela o total e as idades separadas