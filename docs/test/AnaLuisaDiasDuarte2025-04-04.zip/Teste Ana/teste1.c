//1 
#include <stdio.h>

int main(){
    float valorPago, conta;
    int pessoas;

    printf("Total da conta: R$ ", conta);
    scanf("%f", &conta);

    printf("Quantidade de pessoas: ", pessoas);
    scanf("%d", &pessoas);

    valorPago = conta / pessoas;

    printf("Valor a pagar por pessoa: R$%.2f", valorPago);
    scanf("%.2f", &valorPago);

    return 0;
}