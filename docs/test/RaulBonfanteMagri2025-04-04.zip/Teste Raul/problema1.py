total = float(input("Total a pagar: "))
q_pessoa = int(input("Quantidade de Pessoas: "))

valor = round(total/q_pessoa, 2)
diferenca = int(round(total - valor*q_pessoa, 2)*100)
conta = []
for i in range(q_pessoa):
    print(diferenca)
    if diferenca != 0:
        conta.append(valor+0.01)
        diferenca -= 1
        continue
    conta.append(valor)
conta[q_pessoa-1] = round(conta[q_pessoa-1], 2)

for i in range(q_pessoa):
    print(f"Valor a pagar pessoa {i+1}: R$ {conta[i]}")
