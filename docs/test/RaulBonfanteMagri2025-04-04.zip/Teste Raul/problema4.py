while 1:
    ticket = ""

    #Lanche
    while 1:
        x = input("Escolha o lanche('S' Sanduíche, 'C' Cachorro-quente, 'P' pastel): ")
        if x == "S" or x == "C" or x == "P":
            print("Lanche escolhido com sucesso")
            break
        print("Lanche não encontrado, selecione novamente: ")
        continue
    ticket += x
    preco = 0.0

    #Tipo do lanche
    while 1:
        if ticket[0] == "S":
            preco += 5.0
            x = str(input("Escolha o tipo do lanche(1- Vegetariano, 2- Frango, 3- Calabresa): "))
        elif ticket[0] == "C":
            preco += 6.0
            x = str(input("Escolha o tipo do lanche(1- Salsicha tradicional, 2- Salsicha calabresa, 3- Salsicha de frango): "))
        else: 
            preco += 4.0
            x = str(input("Escolha o tipo do lanche(1- Carne, 2- Frango, 3- Presunto e queijo): "))
        
        if x == "1" or x == "2" or x == "3":
            print("Tipo escolhido com sucesso")
            break
        print("Tipo do lanche não encontrado, selecione novamente: ")
        continue
    ticket += x

    #Complemento
    while 1:
        confirmacao = str(input("Deseja algum complemento?(s/n): "))
        if confirmacao == "n":
            x = "0"
            break
        elif confirmacao == "s":
            while 1:
                x = str(input("Escolha o complemento(1- Catupiry, 2- Cream cheese, 3- Barbecue): "))
                if x == "1" or x == "2" or x == "3":
                    print("Complemento escolhido com sucesso")
                    break
                print("Complemento não encontrado, selecione novamente: ")
                continue
            break
        else:
            continue
    ticket += "C"
    ticket += x

    if x == "1":
        preco += 1.0
    elif x == "2":
        preco += 1.2
    else:
        preco += 0.8

    #Bebida
    while 1:
        confirmacao = str(input("Deseja alguma bebida?(s/n): "))
        if confirmacao == "n":
            x = "0"
            break
        elif confirmacao == "s":
            while 1:      
                x = str(input("Escolha a bebida(1- Água, 2- Suco, 3- Refrigerante, 4- Café): "))
                if x == "1" or x == "2" or x == "3" or x == "4":
                    print("Bebida escolhido com sucesso")
                    break
                print("Bebida não encontrado, selecione novamente: ")
                continue
            break
        else:
            continue
    ticket += "B"
    ticket += x

    if x == "1":
        preco += 2.0
    elif x == "2":
        preco += 3.0
    elif x == "3":
        preco += 3.0
    else:
        preco += 2.0

    print(f"LANCHE {ticket} R$ {preco}")
    break
