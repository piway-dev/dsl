total_hospedes = int(input("Quantidade de hóspedes: "))
total_idades = [0,0,0]
#idade = []

for i in range(total_hospedes):
    x = int(input(f"Idade do hóspede {i+1}: "))
    #idade.append(x)
    if x >= 18:
        total_idades[0] += 1
    elif x < 12:
        total_idades[2] += 1
    else:
        total_idades[1] += 1

print(f"\nTotal de hóspedes: {total_hospedes}\nTotal de adultos: {total_idades[0]}\nTotal de Adolescentes: {total_idades[1]}\nTotal de Crianças: {total_idades[2]}")
