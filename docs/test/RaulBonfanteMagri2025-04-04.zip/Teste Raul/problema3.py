q_fileiras = 7
q_poltronas = 10
preco_max = 100.00
preco_fileira = -10
poltronas = []

#Cria as poltronas
for i in range(q_fileiras):
    poltronas.append([])
    for j in range(q_poltronas):
        preco = preco_max+(preco_fileira*i)
        poltronas[i].append([preco,True])

#Função pra printar as poltronas
def print_poltronas():
    print(end="   ")
    for j in range(q_poltronas):
        print(j+1,end=" ")
    print()

    for i in range(q_fileiras):
        print(i+1,end=": ")
        for j in range(q_poltronas):
            if poltronas[i][j][1]:
                print("D ",end="")
                continue
            print("X ",end="")
        print()

#Escolha das poltronas
while 1:
    print_poltronas()
    x = int(input("Número da fileira(1-7): "))-1
    y = int(input("Número da poltrona(1-10): "))-1

    if poltronas[x][y][1]:
        print(f"Poltrona disponivel, preco: R$ {poltronas[x][y][0]}")
        while 1:
            confirmacao = input("Comprar Ingresso?('s' para sim, 'n' para não): ")
            if confirmacao == 's':
                print("Ingresso comprado.")
                poltronas[x][y][1] = False
                break
            elif confirmacao == 'n':
                break
            else:
                continue
    else:
        print("Poltrona ocupada, selecione outra:")
        continue

    confirmacao = input("Deseja ver outras poltronas?('n' para parar, qualquer botão para continuar): ")
    if confirmacao == 'n':
        break
    else:
        continue
