#problema das fileiras do teatro

sala = [["L" for a in range(10)] for a in range(7)]

#mostrar sala

continuar = "sim"

while (continuar == "sim"):
  print("Mapa de assentos")
  for i in range(7):
    print(f"assentos fileira {i+1}: ")
    for g in range(10):
      print(sala[i][g])
    print()


  #pedir fileiro pro usuario

  fileira = int(input("Digite o numero da fileira desejada "))
  poltrona = int(input("Digite o numero da poltrona desejada"))

  if(sala[fileira - 1][poltrona -1]) == "L":
    sala[fileira - 1][poltrona -1 ] = "O"
    preco = 100 - (fileira -1) * 10
  else:
    print("Lugar ocupado, tente novamente para outro assento ") 
  continuar = input("quer comprar mais ingressos? ") 
