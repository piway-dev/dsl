#desafio lanches

tabela = {
  "S": 5.00,
  "C": 6.00,
  "P": 4.00,
  "1": 1.00,
  "2": 1.20,
  "3": 0.80,
  "Agua": 2.00,
  "Suco": 3.00,
  "Refri": 3.00,
  "cafe": 2.00
}


print("Bem vindo ")

lanche = input("Escolha seu lanche ")
cod = lanche


sub_lanche = input("Escolha seu sub-tipo de lanche 1,2,3 ")
cod += sub_lanche

complemento = input("Deseja complemento? ")
if (complemento == "S"):
  cod += "C"
  tipo_complemento = input("escolha seu complemento ")
  cod += tipo_complemento
  valor_comp = tabela[tipo_complemento]
else:
  cod += "0"
  valor_comp = 0

bebida = input("Deseja bebida? ")
if(bebida == "S"):
  bebida_escolhida = input("qual bebida deseja? ")
  bebidas = {"1": "Agua", "2": "Suco","3": "Refri", "4": "cafe"}
  nome_bebida = bebidas[bebida_escolhida]
  valor_bebida = tabela[nome_bebida]
  cod += "B"
else:
  valor_bebida = 0
  cod += "0"

preco_total = tabela[lanche] + valor_bebida + valor_comp
print(f"Lanche {cod} R$ {preco_total:.2f}")

pago_cliente = float(input("Valor pago pelo cliente: "))
troco = pago_cliente - preco_total
print(f"Troco  {troco:.2f}")