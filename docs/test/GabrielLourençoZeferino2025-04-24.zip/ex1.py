


#desafio 1, lanchonete e contas divididas

total_conta = float(input("Valor total da conta: "))
n_pessoas = int(input("Número de pessoas "))

valor_pessoa = total_conta/n_pessoas


for i in range (n_pessoas):
  print(f"Pessoa {i+1} paga: R$ {valor_pessoa:.2f}")

#Entrada:
# - Total da conta: R$ 10,00
# - Quantidade de pessoas: 3
#Saída
 #- Valor a pagar pessoa 1: R$ 3,33
 #- Valor a pagar pessoa 2: R$ 3,33
 #- Valor a pagar pessoa 3: R$ 3,34