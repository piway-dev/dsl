#Exercicio hospedes do hotel
controle = "sim"
num_hospedes = 0
hosp_adulto = 0
hosp_adolescente = 0
hosp_kid = 0
idade_hospede = 0


idade_hospede = 0

while (controle == "sim"):

  idade_hospede = int(input("A idade do hospede é: "))
  num_hospedes +=1
  if(idade_hospede >= 18):
    hosp_adulto += 1
  elif(idade_hospede >= 12):
    hosp_adolescente += 1
  else:
    hosp_kid += 1

  controle = input("continuar? ")

print("Relatório: ")
print(f"Total de hospedes: {num_hospedes}, hospedes adultos {hosp_adulto}, hospedes adolescentes {hosp_adolescente}, e hospedes crianças {hosp_kid}")