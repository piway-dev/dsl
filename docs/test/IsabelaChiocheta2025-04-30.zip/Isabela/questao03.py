fileira = int(input("Digite o numero da fileira escolhida: "))

if fileira == 1:
    print("O ingresso custa R$ 100,00")

elif fileira == 2:
        print("O ingresso custa R$ 90,00")

elif fileira == 3:
        print("O ingresso custa R$ 80,00")

elif fileira == 4:
        print("O ingresso custa R$ 70,00")

elif fileira == 5:
        print("O ingresso custa R$ 60,00")

elif fileira == 6:
        print("O ingresso custa R$ 50,00")

elif fileira == 7:
        print("O ingresso custa R$ 40,00")

elif fileira == 8:
        print("O ingresso custa R$ 30,00")

elif fileira == 9:
        print("O ingresso custa R$ 20,00")

else:
        print("A fileira digitada nao existe")
#não concluida

