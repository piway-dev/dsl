conta = int(input("Digite o valor da conta: "))
qtd_amigos = int(input("Digite a quantidade de amigos: "))

valor_pagar = conta / qtd_amigos

print(f"Valor a pagar por pessoa: {valor_pagar}")