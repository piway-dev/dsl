contador_adulto = 0
contador_adolescente= 0
contador_crianca = 0

num_hospedes = int(input("Digite o número total de hóspedes: "))

while True:
    idade = int(input("Digite a idade do hóspede: (ou -1 quando atingir o numero de hospedes): "))

    if idade == -1:
        break

    if idade >= 18:
        print("Adulto")
        contador_adulto +=1

    elif idade < 12:
        print("Criança") 
        contador_crianca += 1

    elif idade >= 12:
        print("Adolescente")
        contador_adolescente += 1

    else:
        print("A idade digitada não é válida")
        break

print(f"A qantidade de hóspedes é: {num_hospedes}")
print(f"A quantidade de adultos é {contador_adulto}, a quantidade de adolescentes é {contador_adolescente} e a quantidade de crianças é {contador_crianca}")