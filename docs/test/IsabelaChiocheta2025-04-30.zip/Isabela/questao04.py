opcoes = int(input("Qual a sua escolha de lanche? (Digite 1 para Sanduíche, 2 para Cachorro-quente e 3 para Pastel): "))

if opcoes == 1:
    tipo_sanduiche = int(input("1 - Vegetariano, 2 - Frango, 3 - Calabresa: "))

    if tipo_sanduiche:
        complemento = str(input("Aceita o complemento? 1 - Sim, 2 - Nao: "))

        if complemento == 1:
            complemento_desejado = int(input("Digite o complemento desejado: 1 - Catupiry, 2 - Cream Cheese, 3 - Barbecue"))

            if complemento_desejado == 1:
                print ("O complemento escolhido foi o Catupiy")

            elif complemento_desejado == 2:
                print("O complemento escolhido foi  o Cream cheese")

            elif complemento_desejado == 3:
                print("O complemento escolhido foi o Barbecue")

            else:
                print("Voce  não optou por acompanhamento")

if opcoes == 2:
    tipo_c = int(input("1 - Salsicha tradicional, 2 - Salsicha calabresa, 3 - Salsicha de frango"))

    if tipo_c:
        complemento = str(input("Aceita o complemento? 1 - Sim, 2 - Nao: "))

        if complemento == 1:
            complemento_desejado = int(input("Digite o complemento desejado: 1 - Catupiry, 2 - Cream Cheese, 3 - Barbecue"))

            if complemento_desejado == 1:
                print ("O complemento escolhido foi o Catupiy")

            elif complemento_desejado == 2:
                print("O complemento escolhido foi  o Cream cheese")

            elif complemento_desejado == 3:
                print("O complemento escolhido foi o Barbecue")

            else:
                print("Voce  não optou por acompanhamento")

if opcoes == 3:
    tipo_p = int(input("1 - Carne, 2 - Frango, 3 - Presunto e queijo"))

    if tipo_p:
        complemento = str(input("Aceita o complemento? 1 - Sim, 2 - Nao: "))

        if complemento == 1:
            complemento = int(input("Digite o complemento desejado: 1 - Catupiry, 2 - Cream Cheese, 3 - Barbecue: "))

            if complemento == 1:
                print ("O complemento escolhido foi o Catupiy")

            elif complemento == 2:
                print("O complemento escolhido foi  o Cream cheese")

            elif complemento == 3:
                print("O complemento escolhido foi o Barbecue")

            else:
                print("Voce  não optou por acompanhamento")
    
# Não foi possivel terminar
