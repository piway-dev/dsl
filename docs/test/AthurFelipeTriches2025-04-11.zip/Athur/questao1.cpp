#include <iostream>
#include <iomanip>
using namespace std;
int main(){
    int pessoas; float conta;
    cout << "Quantas pessoas no happy hour? ";
    cin >> pessoas;
    cout << endl;
    cout << "Valor da conta: ";
    cin >> conta;
    for (int i = 0; i < pessoas;i++){
        cout << "Valor a pagar pessoa " << i + 1 << ": " << fixed << setprecision(2) << conta / pessoas << endl;
    }
    }
