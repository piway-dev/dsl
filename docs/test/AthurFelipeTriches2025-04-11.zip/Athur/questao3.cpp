#include <iostream>
#include <iomanip>
using namespace std;
//Podia usar matriz mas foi a ideia que deu na hora
//Não consegui fazer o sistema de disponibilidade funcionar, mas o cálculo de preço tá funcionando certinho
int teatro[18];

void prenchearray(){
    for (int i = 1; i < sizeof(teatro);i++){
        teatro[i] = 0;
    }
}

int main(){
    int fila,polt,result; float soma;
    prenchearray();
    while (true)
    {
        cout << "Bem-vindo ao teatro! Qual poltrona deseja? (Fila de 1 a 7 e número de 1 a 10, digite 10 nos dois inputs para sair da compra!)" << endl;
        cout << "Poltronas disponíveis: " << endl;
        for (int i = 1; i < sizeof(teatro)-1; i++){
            if(teatro[i]==0){
                cout << i << " ";
            }
        }
        cout << endl;
        cin >> fila >> polt;
        float preco = 100 - ((fila - 1) * 10);
        result = ((fila * 10) + polt) - 10;
        if(fila==10 && polt==10){
            break;
    }else{
        if(teatro[result]==0){
            teatro[result] == 1;
            cout << "Poltrona Reservada!" << endl;
            soma += preco;
            continue;
        }else{
            cout << "Poltrona já ocupada!";
            continue;
        }
    }
}
cout << "Valor a ser pago: " <<fixed<<setprecision(2)<<soma<< endl;
}
