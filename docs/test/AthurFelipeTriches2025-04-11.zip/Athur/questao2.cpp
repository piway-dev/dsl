#include <iostream>
using namespace std;
int main(){
    int nhospedes, cr = 0, adol = 0, ad = 0, idade;
    cout << "Input hóspedes: ";
    cin >> nhospedes;
    for (int i = 0; i < nhospedes;i++){
        cout << "Input idade do hóspede " << i + 1 << ":";
        cin >> idade;
        if(idade<12 && idade>0){
            cr++;
        }else if(idade>12 && idade<18){
            adol++;
        }else if(idade>18){
            ad++;
        }
    }
    cout << "Núm. total de hóspedes: " << nhospedes << endl;
    cout << "Núm. de crianças: " << cr << endl;
    cout << "Núm. de adolescentes: " << adol << endl;
    cout << "Núm. de adultos: " << ad << endl;
}