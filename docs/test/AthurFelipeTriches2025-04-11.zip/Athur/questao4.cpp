#include <iostream>
#include <iomanip>
using namespace std;
char tipolanche,complemento,bebida;
int varlanche,varcomp,varbeb;
float comanda,valorpago;

void fim(){
    cout << "LANCHE " << tipolanche << varlanche << "C" << varcomp << "B" << varbeb << endl;
    cout << "Valor: " <<fixed<<setprecision(2)<< comanda<<endl;
    cout << "Digite o valor inserido: " << endl;
    cin >> valorpago;
    if(valorpago<comanda){
        cout << "Valor não suficiente" << endl << endl;
        fim();
    }
    else
    {
        cout << "Troco: " << valorpago - comanda << endl;
    }
}

void beb(){
    cout << "Deseja Bebida? (S/N)" << endl;
    cin >> bebida;
    if(bebida=='S' || bebida=='s'){
        cout << "1 - Água, 2 - Suco, 3 - Refrigerante, 4 - Café" << endl;
        cin >> varbeb;
        if(varbeb==1){
            comanda += 2;
            fim();
        }
        else if (varbeb == 2){
            comanda += 1.2;
            fim();
        }
        else if (varbeb == 3){
            comanda += 3;
            fim();
        }
        else if (varbeb == 4){
            comanda += 2;
            fim();
        }
    }
    else if (bebida == 'N' || bebida == 'n'){
        varbeb == 0;
    }
}

void comp(){
    cout << "Deseja complemento? (S/N)" << endl;
    cin >> complemento;
    if(complemento=='S' || complemento=='s'){
        cout << "1 - Catupiry, 2 - Cream cheese, 3 - Barbecue" << endl;
        cin >> varcomp;
        if(varcomp==1){
            comanda += 1;
            beb();
        }else if(varcomp==2){
            comanda += 1.2;
            beb();
        }else if(varcomp==3){
            comanda += 0.8;
            beb();
        }
    }
    else if (complemento == 'N' || complemento == 'n')
    {
        varcomp == 0;
    }
}

int main()
{
    while(true){

    cout << "Bem-vindo ao sistema de cálculo de comanda e pedido" << endl;
    cout << "S - Sanduíche, C - Cachorro-quente, P - Pastel" << endl;
    cin >> tipolanche;
    if(tipolanche=='S' || tipolanche=='s'){
        comanda += 5.0;
        cout << "1- Vegetariano, 2- Frango, 3- Calabresa" << endl;
        cin >> varlanche;
        break;
    }else if(tipolanche=='C' || tipolanche=='c'){
        cout << "1- Salsicha Tradicional, 2- Salsicha Calabresa, 3- Salsicha de frango" << endl;
        cin >> varlanche;
        comanda += 6.0;
        break;
    }else if(tipolanche=='P' || tipolanche=='p'){
        cout << "1- Carne, 2- Frango, 3- Presunto e Queijo" << endl;
        cin >> varlanche;
        comanda += 4.0;
        break;
    }else{
        cout << "Lanche não existe" << endl;
        cout << endl;
        continue;
    }
    }
    comp();
}