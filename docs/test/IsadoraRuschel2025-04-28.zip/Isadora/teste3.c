#include <stdio.h>

int main() {
  // Declarar variáveis
  int lugar[7][10], opcao, fileira, poltrona,qtd;
  
  
  // Inicializa matriz
  for(int i =0;i<7;i++){
    for(int j=0;j<10;j++){
        lugar[i][j]=0;
    }
  }

    while(1){
        printf("Poltronas: (1 = Ocupada, 0 = Livre)\n");
        printf("  1 2 3 4 5 6 7 8 9 10\n");
         for(int i =0;i<7;i++){
            printf("%d ",i+1);
            for(int j=0;j<10;j++){
                printf("%d ",lugar[i][j]);
            }
            printf("\n");
        }
        printf("-----------------------------------------------------\n");
        printf("O que deseja fazer?\n1 - Comprar ingresso\n2 - Sair\n");
        printf("-----------------------------------------------------\n");
        scanf("%d",&opcao);
        if(opcao==1){
            printf("Insira a quantidade de ingressos:\n");
            scanf("%d",&qtd);
            float total=0;
            for(int i=0;i<qtd;i++){
                printf("Insira o número da fileira:\n");
                scanf("%d",&fileira);
                printf("Insira o número da poltrona:\n");
                scanf("%d",&poltrona);
                if(lugar[fileira-1][poltrona-1] || fileira>7 || poltrona>10 || fileira <1 || poltrona<1){
                    printf("Lugar não disponível. Tente novamente.\n");
                    i--;
                    continue;
                }
                else{
                    float preco=100;
                    lugar[fileira-1][poltrona-1]=1;
                    for(int j=0;j<fileira-1;j++){
                        preco-=10;
                    }
                    printf("Valor a pagar pelo ingresso: %.2f\n",preco);
                    total+=preco;
                }
            }
            printf("Valor total: %.2f\n",total);
        }
        else if (opcao==2){
            printf("Saindo...");
            break;
        }
    }


  return 0;
}