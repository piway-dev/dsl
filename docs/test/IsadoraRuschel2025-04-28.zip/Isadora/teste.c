#include <stdio.h>

int main() {
  // Declarar variáveis
  int pessoas;
  double total=0,individual=0,sobra=0;

  printf("Total da conta: ");
  scanf("%lf", &total);

  printf("Quantidade de pessoas: ");
  scanf("%d", &pessoas);
  individual = total/pessoas;
  sobra = (double)(total - individual*pessoas);
  printf("%lf", sobra);
  // Exibir o resultado
  for(int i =0 ; i<pessoas;i++){
    if(i==pessoas-1 && sobra>0)
    {
      individual+=sobra;
      printf("Valor a pagar pessoa %d: R$ %.2lf\n",i,individual);
    }
    else{
      printf("Valor a pagar pessoa %d: R$ %.2lf\n",i,individual);
    }
  }
  

  return 0;
}