#include <stdio.h>

int main() {
    char lanche=' ';
    while(lanche!='X'){
  // Declarar variáveis
        lanche=' ';
        char complemento=' ', opbebida = ' ';
        int subtipo=0,tipoComplemento=0, bebida=0;
        float total = 0;
        printf("----------------------------------------------------------\n");
        printf("Opções:\n(S) Sanduíche\n(C) Cachorro-quente\n(P) Pastel\n(X) Sair\n");
        printf("----------------------------------------------------------\n");
        scanf(" %c",&lanche);
        while(subtipo>3 || subtipo <1){
            if(lanche=='S'){
                printf("Escolha o sub-tipo do lanche:\n1 - Vegetariano\n2 - Frango\n3 - Calabresa\n");
                scanf("%d",&subtipo);
                if(subtipo <1 || subtipo >3){
                    printf("Opção inválida.\n");
                    continue;
                }
                total+=5;
            }
            else if(lanche=='C'){
                printf("Escolha o sub-tipo do lanche:\n1 - Salsicha tradicional\n2 - Salsicha calabresa\n3 - Salsicha de frango\n");
                scanf("%d",&subtipo);
                if(subtipo <1 || subtipo >3){
                    printf("Opção inválida.\n");
                    continue;
                }
                total+=6;
            }
            else if(lanche=='P'){
                printf("Escolha o sub-tipo do lanche:\n1 - Carne\n2 - Frango\n3 - Presunto e queijo\n");
                scanf("%d",&subtipo);
                if(subtipo <1 || subtipo >3){
                    printf("Opção inválida.\n");
                    continue;
                }
                total+=4;
            }
            else if(lanche=='X'){
                printf("Saindo...");
                break;
            }
            else{
                printf("Opção inválida. Reiniciando...\n");
                break;
            }
            while(complemento==' '){            
                printf("Lanche terá complemento? (S/N)\n");
                scanf(" %c",&complemento);
                if(complemento=='S'){
                    while (tipoComplemento<1 || tipoComplemento>3){
                        printf("Qual o complemento desejado?\n1 - Catupiry\n2 - Cream cheese\n3 - Barbecue\n");
                        scanf("%d",&tipoComplemento);
                        if(tipoComplemento==1){
                            total+=1;
                        }
                        else if (tipoComplemento==2){
                            total+=1.2;
                        }
                        else if (tipoComplemento==3){
                            total+=0.8;
                        }
                        else{
                            printf("Opção inválida.\n");
                            continue;
                        }
                        break;
                    }
                }
                else if(complemento!='N'){
                    printf("Opção inválida.\n");
                    complemento= ' ';
                    continue;
                }
            }
            while(opbebida==' '){   
                printf("Deseja bebida? (S/N)\n");
                scanf(" %c",&opbebida);
                if(opbebida=='S'){
                    while(bebida<1 || bebida > 4){
                        printf("Qual bebida?\n1 - Água\n2 - Suco\n3 - Refrigerante\n4 - Café\n");
                        scanf("%d",&bebida);
                        if(bebida>4 || bebida<1){
                            printf("Opção inválida.\n");
                            continue;
                        }
                        else if (bebida==1){
                            total+=2;
                        }
                        else if (bebida == 2 || bebida==3){
                            total+=3;
                        }
                        else {
                            total+=2;
                        }
                        break;
                    }
                }
                else if(opbebida!='N'){
                    printf("Opção inválida.\n");
                    opbebida= ' ';
                    continue;
                }
            }
            printf("LANCHE %c%dC%dB%d R$ %.2f\n",lanche,subtipo,tipoComplemento,bebida,total);
            break;
        }
    }
  return 0;
}