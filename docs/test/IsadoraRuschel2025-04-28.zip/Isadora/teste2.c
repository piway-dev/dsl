#include <stdio.h>

int main() {
  // Declarar variáveis
  int hospedes, adultos=0,adolescentes=0,criancas=0,idade;

    scanf("%d",&hospedes);
  // Exibir o resultado
  for(int i =0 ; i<hospedes;i++){
    printf("Insira sua idade: ");
    scanf("%d",&idade);
    if(idade>=18){
        adultos++;
    }
    else if(idade<12){
        criancas++;
    }
    else{
        adolescentes++;
    }
  }
  printf("Número total de hóspedes: %d\nNúmero total de adultos: %d\nNúmero total de adolescentes: %d\nNúmero total de crianças: %d", hospedes,adultos,adolescentes,criancas);
  
  return 0;
}