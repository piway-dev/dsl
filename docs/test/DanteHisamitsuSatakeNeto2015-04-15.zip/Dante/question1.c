#include <stdio.h>

int main(){
    float total, individual, resto;
    int quan,temp, u;
    printf("Total da conta: R$ ");
    scanf("%f", &total);
    printf("Quantidade de pessoas: ");
    scanf("%d", &quan);
    temp = (total / quan) * 100;
    individual = temp;
    individual /= 100;
    if ((individual * quan) == total)
    {
        for (int i = 0; i < quan;i++){
            printf("Valor a pagar pessoa %d: R$ %.2f\n", i + 1, individual);
        }
    }
    else
    {
        resto = total - (individual * quan);
        u = quan - (resto * 100);
        for (int j = 0; j < quan; j++)
        {
            if (resto > 0){
                printf("Valor a pagar pessoa %d: R$ %.2f\n", j + 1, individual+0.01);
                resto -= 0.01;
            }
            else
            {
                printf("Valor a pagar pessoa %d: R$ %.2f\n", j + 1, individual);
            }
            //printf("Valor a pagar pessoa %d: R$ %.2f\n", j + 1, individual);
        }/*
        for (int k = u; k < quan;k++){
            printf("Valor a pagar pessoa %d: R$ %.2f\n", k + 1, individual+0.01);
        }*/
    }

    return 0;
}