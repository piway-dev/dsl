#include <stdio.h>

int main(){
    
    int check, total = 0, capacidade;
    printf("Digite a capacidade maxima do hotel: ");
    scanf("%d", &capacidade);
    char nome[capacidade][100], adultos[capacidade][100], adol[capacidade][100], crian[capacidade][100];
    int idade[capacidade], adid[capacidade], ado[capacidade], crida[capacidade], tadu=0, tado=0, tcria=0;
    do
    {   
        printf("Digite o nome do hospede: ");
        scanf("%s", &nome[total][0]);
        printf("Digite a idade do hospede: ");
        scanf("%d", &idade[total]);
        if(idade[total]>=18){
            adultos[tadu][0] = nome[total];
            adid[tadu] = idade[total];
            tadu++;
        }
        else if (idade[total] >= 12 && idade[total] < 18)
        {
            adol[tado][0] = nome[total];
            ado[tado] = idade[total];
            tado++;
        }
        else if (idade[total] < 12)
        {
            crian[tcria][0] = nome[total];
            crida[tcria] = idade[total];
            tcria++;
        }
        total++;
        printf("\nTerminou? Digite '1' para terminar, e qualquer outro numero para continuar\n");
        scanf("%d", &check);
    } while (check != 1);

    printf("Numero total de hospedes: %d\n", total);
    printf("Numero total de adultos: %d\n", tadu);
    printf("Numero total de adolescentes: %d\n", tado);
    printf("Numero total de criancas: %d\n", tcria);
    
    return 0;
}