#include <stdio.h>

int main(){
    float valor;
    int poltrona[7][10], check, fil, num, com;
    do{
        for (int i = 0; i < 7; i++)
        {
            for (int j = 0; j < 10;j++){
                if(poltrona[i][j]==1){
                    printf("{O} ");
                }
                else{
                    printf("{ } ");
                }
            }
            printf("\n");
        }
        printf("Digite a fileira e numero da poltrona que quer comprar: ");
        scanf("%d %d", &fil, &num);
        if((fil>0&&fil<8)&&(num>0&&num<11)){
            if(poltrona[fil-1][num-1]!=1){
                valor = 110 - (num * 10);
                printf("O custo do acento é R$ %.2f, deseja continuar? 1 - Sim\n", valor);
                scanf("%d", &com);
                if(com==1){
                    poltrona[fil - 1][num - 1] = 1;
                    printf("Compra feita com successo\n");
                }else{
                    printf("Compra cancelada\n");
                }
            }else {
                printf("Acento ocupado, tente novamente\n");
            }
        } else{
            printf("Acento inexistente, cheque os numero entrados\n");
        }
        printf("Quando terminar, aperte 0 para fechar, e qualquer outro numero para continuar\n");
        scanf("%d", &check);
    }while (check != 0);

    return 0;
}