#include <stdio.h>

int main(){
    char tipo='s', sub='s', comp='s', comple='s', sbeb='s', beb='s', tik[6];
    float total=0;
    int re=0;
    printf("Que tipo de lanche: (S) Sanduiche, (C) Cachorro-quente, (P) Pastel\n");
    scanf("%c", &tipo);
    tik[0] = tipo;
    if (tipo == 'S')
    {
        printf("Escolha o subtipo de lanche: 1 - Vegetariano, 2 - Frango, 3 - Calabresa \n");
        scanf(" %c", &sub);
        tik[1] = sub;
        total += 5;
    }
    else if (tipo == 'C')
    {
        printf("Escolha o subtipo de lanche: 1 - Salsicha tradicional, 2 - Salsicha calabresa, 3 - Salsicha de frango\n");
        scanf(" %c", &sub);
        tik[1] = sub;
        total += 6;
    }
    else if (tipo == 'P')
    {
        printf("Escolha o subtipo de lanche: 1 - Carne, 2 - Frango, 3 - Presunto e queijo\n");
        scanf(" %c", &sub);
        tik[1] = sub;
        total += 4;
    }
    else
    {
        printf("Tipo inválido");
        re = 1;
    }
    if(re!=1){
        printf("Tera complemento? S/N\n");
        scanf(" %c", &comp);
        if(comp=='S'){
            tik[2] = 'C';
            printf("Escolha o complemento: 1 - Catupiry, 2 - Cream cheese, 3 - Barbecue\n");
            scanf(" %c", &comple);
            if(comple=='1'){
                total += 1;
            }else if(comple=='2'){
                total += 1.2;
            }else if(comple=='3'){
                total += 0.8;
            }
            tik[3] = comple;
            tik[4] = 'B';
        }
        else
        {
            tik[2] = '0';
            tik[3] = '0';
            tik[4] = 'B';
        }
        printf("Tera bebida? S/N\n");
        scanf(" %c", &sbeb);
        if(sbeb=='S'){
            printf("Escolha entre as ofertas: 1 - Água, 2 - Suco, 3 - Refrigerante, 4 - Café\n");
            scanf(" %c", &beb);
            if(beb=='1'){
                total += 2;
            }else if(beb=='2'){
                total += 3;
            }else if(beb=='3'){
                total += 3;
            }else if(beb=='4'){
                total += 2;
            }
            tik[5] = beb;
        }else{
            tik[5] = '0';
        }
    }
    printf("LANCHE ");
    for (int c = 0; c < 6; c++)
    {
        printf("%c", tik[c]);
    }
    printf(" R$ %.2f\n\n", total);
    return 0;
}