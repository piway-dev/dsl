//1 
#include <stdio.h>

int main(){
    int x;

    printf("Digite um número: ");
    scanf("%d", &x);

    printf("O quadrado do número é: %d", x*x);

    return 0;
}