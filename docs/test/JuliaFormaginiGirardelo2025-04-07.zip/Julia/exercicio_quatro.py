# Exercicio quatro


print("Bem-vindo ao Sistema EL ALGORITOS \n")
lanche= str(input("Digite conforme a opção de lanche escolhida:\n (S) Sanduíche\n (C) Cachorro-quente\n (P) Pastel\n"))

if lanche == "S":
    totalsandu=5

elif lanche =="C":
    totalcacho=6

elif lanche =="P":
    totalpast=4

#SUBTIPOS

if lanche =='S':
    vars= int(input("Escolha o sub-tipo Sanduiche:1- Vegetariano,2-Frango,3- Calabresa"))

elif lanche == 'C':
    varcacho= int(input("Escolha subtipo Cachorro-quente:1-Salsicha Tradicional\n2-Salsicha calabresa\n3-Salsicha de Frango\n"))

elif lanche== 'P':
    varp= int(input("Escolha subtipo Pastel:\n1-Carne\n2-Frango\n3-Presunto e queijo\n"))
else:
    print("Opção inválida")

#COMPLEMENTO

complemento= str(input("Terias complemento? S-Sim N-Não\n"))

if complemento == 'S':
  varc=int(input("1 - Catupiry, 2 - Cream cheese, 3 - Barbecue \n"))

else:
    print("Sem complemento")

if varc == 1:
    catupi=1

elif varc== 2:
    cream=1.20

elif varc== 3:
    barbecue= 0.80


#BEBIBA 

bebida= str("Gostarias de Adicionar Bebidas? S- Sim N-Não")

if bebida == 'S':
    varb=int(input("1 - Água, 2 - Suco, 3 - Refrigerante, 4 - Café"))
else:
    print("Sem bebidas")

if varb== 1:
    agua=2

elif varb == 2:
    suco= 3

elif varb == 3:
    refri= 3

elif varb==4:
    cafe=2

# codigo tiket

#print(f"Código Tiket:{lanche}{complemento}{varb}")
#preços tabela

soma= lanche + vars or varcacho or varp + complemento + bebida

print(f"Valor Total:R$ {soma}")







