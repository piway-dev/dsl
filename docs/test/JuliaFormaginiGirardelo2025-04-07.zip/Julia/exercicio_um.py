
#Exercicio 1

conta= float(input("Valor total da conta:"))
qnt= int(input("Quantidade de pessoas:"))

pagar= conta / qnt 

print(f"O valor a ser pago por cada um é R$ {pagar}")