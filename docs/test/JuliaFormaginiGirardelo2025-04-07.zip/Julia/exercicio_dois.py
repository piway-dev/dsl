#Exercicio Dois"

num_hospede= int(input("Insira quantas pessoas iram se hospedar"))
idade_hospede= int(input("Insira a idade"))

if idade_hospede > 18:
    print(f"{num_hospede} Adulto ")

elif idade_hospede > 12 and idade_hospede < 16:
    print(f"{num_hospede} Adolescente")

elif idade_hospede < 12:
    print(f"{num_hospede} Criança ")

else:
    print("Inválido")


print("Relatório Hotelaria")
print(f"Total de Hóspedes {num_hospede}")
print("Número de adultos")
print("Número de adolescentes")
print("Número de crianças")
































