#include <stdio.h>

/*

    OBS: Nao tenho dominio do conteudo de arrendodamento ainda, portanto nao esta 100% preciso com o enunciado, irei melhorar e aprender

*/

int main()
{
    float conta = 0.0;
    double valorPagar = 0.0;
    int pessoas = 0;

    printf("Algoritmo de divisao de conta\n");
    printf("Digite o valor total da conta: ");
    scanf("%f", &conta);

    printf("Digite o numero de pessoas: ");
    scanf("%d", &pessoas);

    valorPagar = conta / pessoas;

    printf("Valor a pagar pessoa: R$ %.2lf\n", valorPagar);


    return 0;
}