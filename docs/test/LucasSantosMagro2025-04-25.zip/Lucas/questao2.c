#include <stdio.h>

/*

    OBS: Tive muita dificuldade em adaptar o loop para que o usuario digite varios numeros e pare quando digitar 0, esses conceitos ainda estao abstratos para mim.
         Acredito que a solucao logica seria fazer um array com todos as idades digitas pelo usuario ate digitar 0 para parar o loop, entao fazer uma cadeia condicional
         com todos os valores das idades e separar elas entre adultos, adolescentes e criancas, para assim por fim imprimir o relatorio com o numero total de hospedes e de cada numero total
         de cada idade.
*/

int main()
{

    int hospedes = 0;
    int adultos = 0;
    int adolescentes = 0;
    int criancas = 0;
    int idade = 0;

    while (idade != 0)
    {
        printf("Digite sua idade (aperte 0 para parar): ");
        scanf("%d", &idade);
    }
    
    
    printf("idades = %d", idade);


    return 0;
}