#include <stdio.h>

/*

    OBS: Nao consegui realizar essa questao por nao ter avancado no conteudo de arrays, matrizes, vetores e tive muita dificuldade em adaptar para meus conhecimentos atuais.

*/

int main()
{
    int fileira = 0;
    int poltrona = 0;
    float preco = 0;
    char poltronaDisponivel1[10];
    int fileira1 = 1, fileira2 = 2, fileira3 = 3, fileira4 = 4, fileira5 = 5, fileira6 = 6, fileira7 = 7;

    printf("Poltronas disponiveis: ");

    printf("Digite o numero da fileira: ");
    scanf("%d", &fileira);

    printf("Digite o numero da poltrona: ");
    scanf("%d", &poltrona);



    return 0;
}