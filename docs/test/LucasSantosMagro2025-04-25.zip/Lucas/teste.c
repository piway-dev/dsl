#include <stdio.h>

int main() {
  // Declarar variáveis
  int num1, num2, soma;

  // Obter entrada do usuário (opcional)
  printf("Digite o primeiro número: ");
  scanf("%d", &num1);

  printf("Digite o segundo número: ");
  scanf("%d", &num2);

  // Realizar a soma
  soma = num1 + num2;

  // Exibir o resultado
  printf("A soma de %d e %d é: %d\n", num1, num2, soma);

  return 0;
}