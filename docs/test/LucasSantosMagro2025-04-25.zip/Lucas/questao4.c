#include <stdio.h>

/*

    OBS1: O C nao deixou fazer (S/N) pois implicava com ponteiros, entao adaptei para 1 - sim e 2 - nao.
    OBS2: Para melhor otimizacao o codigo poderia ser feito com switch, mas preferi fazer com if else por ter mais familiaridade.

*/



int main()
{

    char lanche = '\0';
    int tipoLanche = 0;
    int subTipo = 0;
    int complementoTipo = 0;
    int bebidaTipo = 0;
    int complemento = 0;
    char complementoChar = '\0';
    char bebidaChar = '\0';
    int bebida = 0;
    float precoSand = 0.00, precoCachorro = 0.00, precoPastel = 0.00, precoCatupiry = 0.00, precoCream = 0.00, precoBarbecue = 0.00, precoAgua = 0.00, precoSuco = 0.00, precoRefri = 0.00, precoCafe = 0.00;
    float valorTotal = 0.0;
    float valorPago = 0.0;
    float valorTroco = 0.0;

    printf("\nS - Sanduiche\n");
    printf("C - Cachorro-Quente\n");
    printf("P - Pastel\n");
    printf("Digite sua opcao de lanche (S, C ou P): ");
    scanf("%c", &lanche);

    if (lanche == 'S' || lanche == 's')
    {
        printf("1 - Vegetariano\n");
        printf("2 - Frango\n");
        printf("3 - Calabresa\n");
        printf("Digite o sub-tipo do sanduiche: ");
        scanf("%d", &subTipo);
        precoSand = 5.00;
    }
    else if (lanche == 'C' || lanche == 'c')
    {
        printf("1 - Salsicha Tradicional\n");
        printf("2 - Salsicha Calabresa\n");
        printf("3 - Salsicha de Frango\n");
        printf("Digite o sub-tipo do sanduiche: ");
        scanf("%d", &subTipo);
        precoCachorro = 6.00;
    }
    else if (lanche == 'P' || lanche == 'p')
    {
        printf("\n1 - Carne\n");
        printf("2 - Frango\n");
        printf("3 - Presunto e Queijo\n");
        printf("Digite o sub-tipo do sanduiche: ");
        scanf("%d", &subTipo);
        precoPastel = 4.00;  
    }
    else
    {
        printf("Digite um valor valido!\n");
        return 1;
    }

    printf("\n1 - sim\n");
    printf("2 - nao\n");
    printf("O lanche tera complemento? ");
    scanf("%d", &complemento);

    if (complemento == 1)
    {
        printf("\n1 - Catupiry\n");
        printf("2 - Cream Cheese\n");
        printf("3 - Barbecue\n");
        printf("Digite o complemento desejado: ");
        scanf("%d", &complementoTipo);
        complementoChar = 'C';
            if (complementoTipo == 1)
            {
                precoCatupiry = 1.00;
            }
            else if (complementoTipo == 2 )
            {
                precoCream = 1.20;
            }
            else if (complementoTipo == 3)
            {
                precoBarbecue = 0.80;
            }         
    }
    else if (complemento == 2)
    {
        complementoChar = 'C';
        complementoTipo = 0;
    }
    else
    {
        printf("Digite um valor valido!\n");
        return 1;
    }

    printf("\n1 - sim\n");
    printf("2 - nao\n");
    printf("Gostaria de uma bebida? ");
    scanf("%d", &bebida);

    if (bebida == 1)
    {
        printf("\n1 - Agua\n");
        printf("2 - Suco\n");
        printf("3 - Refrigerante\n");
        printf("4 - Cafe\n");
        printf("Digite sua opcao de bebida: ");
        scanf("%d", &bebidaTipo);
        bebidaChar = 'B';
            if (bebidaTipo == 1)
            {
                precoAgua = 2.00;
            }
            else if (bebidaTipo == 2)
            {
                precoSuco = 3.00;
            }
            else if (bebidaTipo == 3)
            {
                precoRefri == 3.00;
            }
            else if (bebidaTipo == 4)
            {
                precoCafe == 2.00;
            }
            
    }
    else if (bebida == 2)
    {
        bebidaChar = 'B';
        bebidaTipo = 0;
    }
    else
    {
        printf("Digite um valor valido!\n");
        return 1;
    }

    valorTotal = precoSand + precoCachorro + precoPastel + precoCatupiry + precoCream + precoBarbecue + precoAgua + precoSuco + precoRefri + precoCafe;

    printf("LANCHE %c%d%c%d%c%d R$ %.2f\n", lanche, subTipo, complementoChar, complementoTipo, bebidaChar, bebidaTipo, valorTotal);
    
    printf("Qual o valor pago? ");
    scanf("%f", &valorPago);

    valorTroco = valorPago - valorTotal;

    if (valorPago < valorTotal)
    {
        printf("Informe um valor maior ou igual o valor total!\n");
        return 1;
    }
    else
    {
        printf("O valor do troco e: R$%.2f\n", valorTroco);
    }
    
    return 0;
}