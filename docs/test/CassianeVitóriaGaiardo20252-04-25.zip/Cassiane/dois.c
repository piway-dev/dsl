#include <stdio.h>

int main() {
  int tot_pessoa, adultos=0, adolescentes=0, criancas=0, idade=0;
  

  printf("Digite quantos hóspedes há: ");
  scanf("%d", &tot_pessoa);

  for (int i = 0; i < tot_pessoa;i++){
      printf("Qual a idade deste hóspede?\n");
      scanf("%d", &idade);
      if(idade>=111){ // qual será a idade da pessoa mais velha do mundo?
          printf("Esta idade é impossível!! \nDigite a idade do hóspede novamente: "); 
          scanf("%d", &idade);
        }
      if ((idade >= 18)&&(idade<111)){ 
          adultos += 1;
      }else{
        if((idade>=12) && (idade<18)){
            adolescentes += 1;
        }else{
            if(idade<12){
                criancas += 1;
            }
        }
      }

  }

  printf("Relatório:\nTotal de pessoas hospedadas: %d \ncrianças: %d \nadolescentes: %d \nadultos: %d\n", tot_pessoa, criancas, adolescentes, adultos);

  return 0;
}