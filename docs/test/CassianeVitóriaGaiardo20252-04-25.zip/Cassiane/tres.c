#include <stdio.h>

int main() {
  int matriz[7][10];
  int ing, valor;
  int fileira, num_poltrona;

  for (int i = 0; i < 7; i++){
    for (int j = 0; j < 10;j++){
        matriz[i][j] = 0; // 0 = desocupada
    }
  }  

  for (int i = 0; i < 7; i++){
    for (int j = 0; j < 10;j++){
        printf("%d ", matriz[i][j]);

    }
    printf("\n");
  }
  printf("Digite 1 para comprar um ingresso: \n");
  scanf("%d", &ing);
  while(ing==1){ 

    printf("Digite fileira e numero da poltrona (ex.: 1 1):");
    scanf("%d %d", &fileira, &num_poltrona);
    if (matriz[fileira-1][num_poltrona-1] == 0)
    {
        matriz[fileira-1][num_poltrona-1] = 1; // ocupada
        valor = 100 - ((fileira-1) * 10); // supondo que a primeira fileira da matriz é a linha 0!!!!!!

        printf("o valor desta poltrona é: R$ %d,00\n", valor);

        printf("Seu ingresso foi comprado com sucesso!\n");
        for (int i = 0; i < 7; i++){ //mostra matriz
            for (int j = 0; j < 10;j++){
                printf("%d ", matriz[i][j]);
        
            }
            printf("\n");
          }

          printf("Deseja comprar outro ingresso? 1=sim 0=não \n");
        scanf("%d", &ing);
        if(ing !=1){ // 0 ou qualquer outro
        return 0;
        }
    }
    else
    {
        printf("Esta poltrona está ocupada!\n");
    }
}
  // 0 0 insere e não deveria!!
  return 0;
}