#include <stdio.h>

int main() {
  int num_pessoa;
  double total, result;

  printf("Digite o total da conta: ");
  scanf("%lf", &total);

  printf("Digite o número de pessoas: ");
  scanf("%d", &num_pessoa);

  result =  total / num_pessoa;
  printf("O resultado é: %.2lf cada\n", result);







  
  return 0;
}