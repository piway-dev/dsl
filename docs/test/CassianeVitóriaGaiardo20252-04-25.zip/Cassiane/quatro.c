#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main() {
  int op, escolha_complem, escolha_bebida;
  int sub,  complem,  bebida ;
  double valor;

  printf("Digite : (1) Sanduíche, (2) Cachorro-quente, (3) Pastel: ");
  scanf("%d", &op);

  //printf("%c", toupper(op));
  //printf("%d", strcmp('S', toupper(op))); erro aq !! portanto eu vou mudar as opções para inteiro para concluir a questão

  if(op==1){
      valor += 5.0;
      printf("(1 - Vegetariano, 2 - Frango, 3 - Calabresa)");
      scanf("%d", &sub);
  }else if (op==2){
      valor += 6.0;
      printf("(1 - Salsicha tradicional, 2 - Salsicha calabresa, 3 - Salsicha de frango)");
      scanf("%d", &sub);
  }else if (op==3)
  {
    valor += 4.0;
    printf("(1 - Carne, 2 - Frango, 3 - Presunto e queijo)");
    scanf("%d", &sub);
  }
  
      printf("Deseja um complemento? 1 = sim");
      scanf("%d", &escolha_complem);
      if (escolha_complem == 1)
      {
          printf("(1 - Catupiry, 2 - Cream cheese, 3 - Barbecue)");
          scanf("%d", &complem);
          if(complem==1){
              valor += 1.0;
          }else if (complem==2)
          {
              valor += 1.2;
          }else if (complem==3)
          {
              valor += 0.8;
          }
      }else{
          complem = 0;
      }
    printf("Deseja uma bebida? 1 = sim");
    scanf("%d", &escolha_bebida);
    
    if(escolha_bebida == 1){
        printf("(1 - Água, 2 - Suco, 3 - Refrigerante, 4 - Café)");
        scanf("%d", &bebida);
        if(bebida==1 || bebida==4){
            valor += 2.0;
        }else if (complem==2 || complem==3)
        {
            valor += 3.0;
        }
    }else if (escolha_bebida!=1)
    {
        bebida = 0;
    }

printf("%d %d C %d B %d\n", op, sub, complem, bebida);
printf("valor total é: %.2lf\n", valor);

return 0;
}