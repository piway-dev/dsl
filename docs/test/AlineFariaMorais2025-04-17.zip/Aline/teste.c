#include <stdio.h>
#include <stdlib.h>


//Questão 1
typedef struct conta
{
    float valor_conta;
    int numero_pessoas;
    float valor_dividido;
    float sobra;
} Conta;


void divisao(Conta *conta){

    float valor_dividido = 0;
    float sobra = 0;
    float valor_conta = 0;
    int numero_pessoas = 0;

    printf("Digite o valor da conta total e o numero de pessoas a pagar\n");
    scanf("%f, %d", valor_conta, numero_pessoas);

    conta->valor_conta = valor_conta;
    conta->numero_pessoas = numero_pessoas;

    if(conta->valor_conta > 0){
        
        sobra = (int) conta->valor_conta % conta->numero_pessoas;  
        conta->sobra = sobra;

        if(sobra == 0){
            valor_dividido = conta->valor_conta / conta->numero_pessoas;
            conta->valor_dividido = valor_dividido;
            for (int i = 0; i < conta->numero_pessoas; i++){
                printf("Valor a pagar pessoa %d: R$ %.2f\n", i + 1, conta->valor_dividido);
            }
        }

        else{
            valor_dividido = conta->valor_conta / conta->numero_pessoas;
            conta->valor_dividido = valor_dividido;
            for (int i = 0; i < conta->numero_pessoas; i++){
                printf("Valor a pagar pessoa %d: R$ %.2f\n", i + 1, conta->valor_dividido);
                if(i+1 == conta->numero_pessoas){
                printf("Valor a pagar pessoa %d: R$ %.2f\n", i + 1, conta->valor_dividido + conta->sobra);
                }
                return conta->numero_pessoas;
            }
        }


    }

    return;
}

//Questão 2
typedef struct hospedes{
    int adultos;
    int adolescentes;
    int criancas;
    int total_hospedes;
} Hospedes;

typedef struct idades{
    int idade_adultos;
    int idade_adolescentes;
    int idade_criancas;
} Idades;

void conta_hospedes(Hospedes *hospedes, Idades *idades){

    int idade = 0;

    printf("Insira a quantidade de hospedes: ");
    scanf("%d\n", &hospedes->total_hospedes);

    
    for (int i = 0; i < hospedes->total_hospedes; i++){
        printf("Insira a idade do hospede (crianças com menos de 1 ano devem ser inseridas com idade igual a 1) %d: ", i);
        scanf("%d", idade);

        if(idade >= 18 && idade < 130){
            idades->idade_adultos = idade;
            hospedes->adultos++;
        }
        else if (idade < 18 && idade > 12){
            idades->idade_adolescentes = idade;
            hospedes->adolescentes++;
        }
        else if (idade < 12 && idade > 0)
        {
            idades->idade_criancas = idade;
            hospedes->criancas++;
        }
        else
            printf("Idade invalida!");

        return;
    }
    return;
}

//Questão 3
typedef struct salas{
    int sala[7][10];
    int valor_total;
    int poltronas_disponiveis;
    int poltronas_ocupadas;
} Salas;

void preenche_sala(Salas *salas){
    int sala[7][10] = 0;
    int disponiveis = 0;
    int ocupadas = 0;

    
    for (int i = 0; i < sala[7][10]; i++){
        for (int j = 0; j < sala[7][10]; j++){
            
        }
        
    }
    
    
}

int main(){

    
    //Questão 1
    Conta *conta;
    divisao(conta);

    /*10
    //Questão 2
    Hospedes *hospede;
    Idades *idade;
    conta_hospedes(hospede, idade);

    //Questão 3
    */

    int a = 10 % 3;
    printf("%d",a);

    return 0;
}
