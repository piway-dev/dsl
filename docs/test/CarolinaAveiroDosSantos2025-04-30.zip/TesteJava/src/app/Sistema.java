package app;

import app.exercicios.DividirConta;
import app.exercicios.RelatorioHospedes;
import app.exercicios.SistemaLanches;
import app.exercicios.TeatroVendas;

import java.util.Scanner;

public class Sistema {
    public static void main (String[]args){

        Scanner scanner = new Scanner(System.in);

        int opcao;

        do{
            System.out.println("\n=== Menu ===\n1. Dividir conta pela quantidade de pessoas\n2. Relatório Hospedes\n3. Teatro \n4. Sistema Lanches\n0. Sair\n");
            opcao=scanner.nextInt();
            scanner.nextLine();

            switch (opcao){
                case 1:
                    DividirConta.executar(scanner);
                    break;
                case 2:
                    RelatorioHospedes.executar(scanner);
                    break;
                case 3:
                    TeatroVendas.executar(scanner);
                case 4:
                    SistemaLanches.executar(scanner);
                    break;
                case 0:
                    System.out.println("\nSaindo...\n");
                    break;
                default:
                    System.out.println("\nAlgo deu errado!\n");
            }
        }while(opcao!=0);

        scanner.close();
    }


}
