package app.exercicios;

import app.exercicios.entidades.Sanduiche;
import app.exercicios.entidades.TipoSanduiche;

import java.util.ArrayList;
import java.util.Scanner;


public class SistemaLanches {

    static ArrayList<Sanduiche> sanduiches = new ArrayList();


    public static void sistemaLanches(){

        Scanner scanner = new Scanner(System.in);
        int opcao;

        do{
            System.out.println("\n=== Menu Lanches ===\n1. Sanduiche\n2. Cachorro-Quente\n3. Pastel\n0. Sair\n");
            opcao=scanner.nextInt();
            scanner.nextLine();

            switch (opcao){
                case 1:
                    //sanduiche(scanner);
                    comprarSanduiche(scanner);
                    break;
                case 2:
                    break;
                case 3:
                    break;
                case 0:
                    System.out.println("\nSaindo...\n");

            }

        }while(opcao!=0);
    }

    public static void executar(Scanner scanner){
        inicializarSanduiches(scanner);
        sistemaLanches();

    }

    public static void comprarSanduiche(Scanner scanner) {
        System.out.println("\n=== Escolha o tipo de sanduíche ===");
        for (int i = 0; i < sanduiches.size(); i++) {
            Sanduiche sanduiche = sanduiches.get(i);
            System.out.printf("%d. %s - R$ %.2f\n", sanduiche.getNumero(), sanduiche.getTipoSanduiche(), sanduiche.getPreco());
        }
        System.out.print("Escolha uma opção: ");
        int escolha = scanner.nextInt();
        scanner.nextLine();

        Sanduiche sanduicheEscolhido = sanduiches.stream()
                .filter(s -> s.getNumero() == escolha)
                .findFirst()
                .orElse(null);

        if (sanduicheEscolhido != null) {
            System.out.println("\nVocê escolheu: " + sanduicheEscolhido.getTipoSanduiche());
            System.out.println("Preço: R$ " + sanduicheEscolhido.getPreco());
            double total = sanduicheEscolhido.getPreco();

            System.out.println("\nDeseja acompanhamento?");
            System.out.println("1. Sim");
            System.out.println("2. Não");
            System.out.print("Escolha uma opção: ");
            int opcao = scanner.nextInt();
            scanner.nextLine();

            if (opcao == 1) {
                System.out.println("\n=== ACOMPANHAMENTOS ===");
                System.out.println("1. Catupiry (R$ 1.00)");
                System.out.println("2. Cream Cheese (R$ 1.20)");
                System.out.println("3. Barbecue (R$ 0.80)");
                System.out.print("Escolha uma opção: ");
                int acompanhamento = scanner.nextInt();
                scanner.nextLine();

                double precoAcompanhamento = switch (acompanhamento) {
                    case 1 -> 1.00;
                    case 2 -> 1.20;
                    case 3 -> 0.80;
                    default -> 0.00;
                };

                if (precoAcompanhamento > 0) {
                    total += precoAcompanhamento;
                    System.out.printf("\nVocê escolheu o acompanhamento. Preço total: R$ %.2f\n", total);
                } else {
                    System.out.println("\nOpção de acompanhamento inválida.");
                }
            } else {
                System.out.printf("\nOk! Sem acompanhamento! Preço total: R$ %.2f\n", total);
            }

            System.out.print("\nInsira o valor pago: R$ ");
            double valorPago = scanner.nextDouble();
            scanner.nextLine();

            if (valorPago >= total) {
                double troco = valorPago - total;
                System.out.printf("\nTroco: R$ %.2f", troco);
            } else {
                System.out.printf("\nOpa! Valor insuficiente. Faltam R$ %.2f\n", total - valorPago);
            }
        } else {
            System.out.println("\nOpção de sanduíche inválida.");
        }
    }




    public static void inicializarSanduiches(Scanner scanner){

        System.out.println("\n=== Menu Sanduiche ===\n1. ");

        Sanduiche sanduiche1 = new Sanduiche();
        double preco1 = 5.00;
        int numero1 = 1;
        //sanduiche 1
        sanduiche1.setNumero(numero1);
        sanduiche1.setPreco(preco1);
        sanduiche1.setTipoSanduiche(TipoSanduiche.VEGETARIANO);


        sanduiches.add(sanduiche1);

        Sanduiche sanduiche2 = new Sanduiche();
        double preco2 = 5.00;
        //sanduiche 2
        int numero2=2;

        sanduiche2.setNumero(numero2);
        sanduiche2.setPreco(preco2);
        sanduiche2.setTipoSanduiche(TipoSanduiche.FRANGO);

        sanduiches.add(sanduiche2);

        Sanduiche sanduiche3 = new Sanduiche();
        double preco3 = 5.00;
        //sanduiche 3
        int numero3=3;

        sanduiche3.setNumero(numero3);
        sanduiche3.setPreco(preco3);
        sanduiche3.setTipoSanduiche(TipoSanduiche.CALABRESA);

        sanduiches.add(sanduiche3);



    }
}
