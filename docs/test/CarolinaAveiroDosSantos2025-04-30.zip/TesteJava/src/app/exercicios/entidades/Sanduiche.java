package app.exercicios.entidades;

public class Sanduiche {

    private Enum<TipoSanduiche>tipoSanduiche;

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    private int numero;

    private Double preco;

    public Double getPreco() {
        return preco;
    }

    public void setPreco(Double preco) {
        this.preco = preco;
    }



    public Enum<TipoSanduiche> getTipoSanduiche() {
        return tipoSanduiche;
    }

    public void setTipoSanduiche(Enum<TipoSanduiche> tipoSanduiche) {
        this.tipoSanduiche = tipoSanduiche;
    }

    public Sanduiche(Enum<TipoSanduiche> tipoSanduiche, int numero, Double preco) {
        this.tipoSanduiche = tipoSanduiche;
        this.numero = numero;
        this.preco = preco;
    }

    public Sanduiche(){

    }
}
