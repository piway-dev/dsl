package app.exercicios.entidades;

public enum TipoSanduiche {
    VEGETARIANO,
    FRANGO,
    CALABRESA,
}
