package app.exercicios.entidades;

public class Poltrona {

    private int numero;
    private double preco;
    private int fileira;
    private Enum<Disponibilidade> disponibilidade;

    public int getFileira() {
        return fileira;
    }

    public void setFileira(int fileira) {
        this.fileira = fileira;
    }



    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public Enum<Disponibilidade> getDisponibilidade() {
        return disponibilidade;
    }

    public void setDisponibilidade(Enum<Disponibilidade> disponibilidade) {
        this.disponibilidade = disponibilidade;
    }

    public Poltrona(int numero, double preco, Enum<Disponibilidade> disponibilidade) {
        this.numero = numero;
        this.preco = preco;
        this.disponibilidade = disponibilidade;
    }
    public Poltrona(){

    }
}
