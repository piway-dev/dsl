package app.exercicios.entidades;

public enum Disponibilidade {
    DISPONIVEL,
    INDISPONIVEL,
}
