package app.exercicios;

import app.exercicios.entidades.Disponibilidade;
import app.exercicios.entidades.Poltrona;

import java.net.StandardSocketOptions;
import java.util.ArrayList;
import java.util.Scanner;

public class TeatroVendas {

    static ArrayList<Poltrona> poltronas = new ArrayList<>();
   public static void teatroVendas(){
       Scanner scanner = new Scanner(System.in);
       int opcao;


       do{
           System.out.println("\n=== Menu Teatro ===\n1. Adicionar Lugar\n2. Comprar\n3. Ver Todos\n4. ..\n0. Sair\n");
           opcao = scanner.nextInt();
           scanner.nextLine();

           switch (opcao){
               case 1:
                   addLugar(scanner);
                   break;
               case 2:
                   comprar(scanner);
                   break;
               case 3:
                   listarTodos();
                   break;
               case 0:
                   System.out.println("\nSaindo...\n");
                   break;
               default:
                   System.err.println("\nAlgo deu errado!");
           }

       }while(opcao!=0);
   }

    public static void executar(Scanner scanner){
        teatroVendas();
    }

    public static void listarTodos(){
       if(poltronas.isEmpty()){
           System.err.println("\nNenhuma poltrona cadastrada\n");
       }

       for(Poltrona p : poltronas){
           System.out.println("\nNúmero: "+p.getNumero()+"\nPreço: "+p.getPreco()+"\nStatus: "+p.getDisponibilidade()+"\nFileira: "+p.getFileira());
       }
    }

    public static void comprar(Scanner scanner){
        if(poltronas.isEmpty()){
            System.err.println("\nNenhuma poltrona cadastrada\n");
            return;
        }


        System.out.println("\nDigite o lugar desejado: ");
       int numero = scanner.nextInt();
       scanner.nextLine();

       for(Poltrona p: poltronas){
           if(p.getNumero()==numero){

               if(p.getDisponibilidade()== Disponibilidade.INDISPONIVEL){
                System.err.println("\nOpa! Essa poltrona não está disponível!\n");
                return;
               }

               System.out.println("\nFileira: "+p.getFileira()+"  Preço: R$"+p.getPreco()+" Disponibilidade: "+p.getDisponibilidade());
               System.out.println("\nInsira um valor (Ex: 100,00)para calcular o troco:\n");
               double pagamento = scanner.nextDouble();
               scanner.nextLine();
               double troco = pagamento-p.getPreco();
               System.out.println("\nTroco: R$ %.2f"+troco);
               p.setDisponibilidade(Disponibilidade.INDISPONIVEL);//cliente ja comprou
           }
       }

    }

    public static void addLugar(Scanner scanner){
        Poltrona poltrona = new Poltrona();

        System.out.println("\nNumero: \n");
        int numero = scanner.nextInt();
        poltrona.setNumero(numero);


        System.out.println("\nFileira: \n");
        int fileira = scanner.nextInt();
        scanner.nextLine();

        poltrona.setFileira(fileira);

        if(fileira==1){
            double preco=100.00;
            poltrona.setPreco(preco);
        }else if(fileira==2){
            double preco=90.00;
            poltrona.setPreco(preco);
        }else if(fileira==3){
            double preco=80.00;
            poltrona.setPreco(preco);
        }else if(fileira==4){
            double preco=70.00;
            poltrona.setPreco(preco);
        }else if(fileira==5){
            double preco=60.00;
            poltrona.setPreco(preco);
        }else if(fileira==6){
            double preco=50.00;
            poltrona.setPreco(preco);
        }else if(fileira==7){
            double preco=40.00;
            poltrona.setPreco(preco);
        }

        poltrona.setDisponibilidade(Disponibilidade.DISPONIVEL);
        poltronas.add(poltrona);
        System.out.println("\nAdicionado com sucesso!\n");

    }
}
