package app.exercicios;

import java.util.Scanner;

public class DividirConta {
    public static void dividirConta() {
        System.out.println("\nQual o valor total da conta?\n");
        Scanner scanner = new Scanner(System.in);
        double conta = scanner.nextDouble();
        scanner.nextLine();

        System.out.println("\nQual a quantidade de pessoas?\n");
        int pessoas = scanner.nextInt();
        scanner.nextLine();

        int valorInteiro = (int) (conta * 100);
        int valorPorPessoa = valorInteiro / pessoas;
        int resto = valorInteiro % pessoas;

        System.out.println("\nValores por pessoa:");
        for (int i = 0; i < pessoas; i++) {
            if (i < resto) {
                System.out.printf("Pessoa %d: %.2f\n", i + 1, (valorPorPessoa + 1) / 100.0);
            } else {
                System.out.printf("Pessoa %d: %.2f\n", i + 1, valorPorPessoa / 100.0);
            }
        }


    }

    public static void executar(Scanner scanner){
        dividirConta();
    }
}
