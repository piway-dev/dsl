package app.exercicios;

import app.exercicios.entidades.Hospede;

import java.util.ArrayList;
import java.util.Scanner;

public class RelatorioHospedes {


    static ArrayList<Hospede> hospedes = new ArrayList();
    public static void relatorioHospedes(){
         Scanner scanner = new Scanner(System.in);
         int opcao;

         do{
             System.out.println("\n=== Menu Hotel ===\n1.  Adicionar Hóspede\n2. Remover hóspede\n3. Todos os hóspedes\n4. Total adultos\n5. Total adolescentes\n6. Total crianças\n0. Sair\n");
             opcao = scanner.nextInt();
             scanner.nextLine();

             switch (opcao){
                 case 1:
                     addHospede(scanner);
                     break;
                 case 2:
                     removerHospede(scanner);
                 case 3:
                     listarTudo();
                     break;
                 case 4:
                     listarAdultos();
                     break;
                 case  5:
                     listarAdolescentes();
                     break;
                 case 6:
                    listarCriancas();
                     break;
                 case 0:
                     System.out.println("\nSaindo...");
                     break;
                 default:
                     System.out.println("\nAlgo deu errado!");

             }

         }while(opcao!=0);

    }

    public static void executar(Scanner scanner){
        relatorioHospedes();

    }

    public static void addHospede(Scanner scanner){
        Hospede hospede = new Hospede();

        System.out.println("\nNome: \n");
        String nome = scanner.nextLine();
        hospede.setNome(nome);

        System.out.println("\nIdade: \n");
        int idade = scanner.nextInt();
        scanner.nextLine();
        hospede.setIdade(idade);

        hospedes.add(hospede);

    }

    public static void listarTudo(){
        if(hospedes.isEmpty()){
            System.err.println("\nNenhum hóspede cadastrado!\n");
        }

        for(Hospede h : hospedes){
            System.out.println("\nNome: "+h.getNome()+"\nIdade: "+h.getIdade()+"\n");
        }

    }

    public static void listarAdultos(){
        if(hospedes.isEmpty()){
            System.err.println("\nNenhum hóspede cadastrado!\n");
        }

        for(Hospede h : hospedes){
            if(h.getIdade()>18){
                System.out.println("\nNome: "+h.getNome()+"\nIdade: "+h.getIdade()+"\n");
            }
        }
    }

    public static void listarAdolescentes(){
        if(hospedes.isEmpty()){
            System.err.println("\nNenhum hóspede cadastrado!\n");
        }

        for(Hospede h : hospedes){
            if(h.getIdade()>12 & h.getIdade()<17){
                System.out.println("\nNome: "+h.getNome()+"\nIdade: "+h.getIdade()+"\n");
            }
        }
    }

    public static void listarCriancas(){
        if(hospedes.isEmpty()){
            System.err.println("\nNenhum hóspede cadastrado!\n");
        }

        for(Hospede h : hospedes){
            if(h.getIdade()<12){
                System.out.println("\nNome: "+h.getNome()+"\nIdade: "+h.getIdade()+"\n");
            }
        }
    }

    public static void removerHospede(Scanner scanner){

        System.out.println("\nNome do hóspede a ser removido: \n");
        String nomeRemove = scanner.nextLine();

        boolean encontrado = false;
        for(Hospede h : hospedes){
            if(nomeRemove.equalsIgnoreCase(h.getNome())){
                hospedes.remove(h);
                encontrado=true;
                break;
            }
        }
        if(encontrado){
            System.out.println("\nRemovido com sucesso!\n");
            System.out.println("\nRestantes: \n");
        }

    }
}
